# -*- coding: utf-8 -*-
import scrapy
import hashlib
import os
import dateparser
import stat
import requests
import youtube_dl
import urllib
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
from scrapy import Request
from scrapy.utils.project import get_project_settings
from xbwj.items import XzItem
from newspaper import Article


class XzxwSpider(CrawlSpider):
    name = 'xbwj'
    allowed_domains = ['tibetanwomen.org']
    start_urls = ['https://tibetanwomen.org/']

    rules = (
        Rule(LinkExtractor(allow=r'https://tibetanwomen.org/$'), callback='parse_news', follow=False),

    )

    # ===每个网站自己解析新闻的函数

    def parse_news(self, response):

        news_link = response.xpath('.//div[@class="entries-wrapper"]/div//h2/a/@href').extract()
        news_time = response.xpath('.//p[@class="default_date"]/span[@class="year"]/text()').extract()

        info = zip(news_link, news_time)
        for l, t in info:
            if int(t) == 2019:
                yield Request(response.urljoin(l), meta=response.meta, callback=self.parse_item)

        for pn in range(2, 4):
            url = 'https://tibetanwomen.org/page/{}/'.format(pn)
            yield Request(url, callback=self.parse_news)

    # ====================

    def parse_ajax_news(self, response):
        news_list = response.xpath('.//div[@class="cardContent"]/h3/a/@href').extract()
        for news in news_list:
            yield Request(news, callback=self.parse_item)

        for i in range(1, 3):
            url = 'https://www.dalailama.com/news/p{}'.format(i)
            yield Request(url, callback=self.parse_ajax_news)

    def parse_pic(self, response):
        pt_list = []
        pic_time = response.xpath('.//p[@class="meta"]/text()').extract()
        for pt in pic_time:
            pt = pt.replace('Febraury', 'February')
            pt_list.append(dateparser.parse(pt))

        pic_news = response.xpath('.//div[@class="image"]/a/@href').extract()
        pic_info = zip(pt_list, pic_news)
        for t, n in pic_info:
            try:
                if t >= dateparser.parse('2019-01-01'):
                    response.meta['time'] = t
                    yield Request(n, meta=response.meta, callback=self.parse_item)
            except TypeError:
                continue

    def hash(self, url):
        m = hashlib.md5()
        m.update(url.encode("utf8"))
        return m.hexdigest()

    def pic_download(self, response, purl):    # 下载图片,purl:被下载图片的url
        """

        :param purl:   每个图片的url
        :param response:   response
        :return:       图片列表
        """
        paths = './image'
        if not os.path.exists(paths):
            os.makedirs(paths)
            os.chmod("./image", stat.S_IWOTH)  # 可被写入
        pat = paths + '/{}.{}'.format(self.hash(purl), purl.split('?')[0].split('.')[-1])  # 可能有png格式 0330
        header = get_project_settings().get('DEFAULT_REQUEST_HEADERS')
        with open(pat, 'wb') as f:
            # f.write(requests.get(purl, headers=header).content)
            f.write(urllib.request.urlopen(purl).read())

    def article_img(self, pic_url, timg, response):
        """

        :param pic_url:  这个网页的所有图片url（包括非新闻的）   set
        :param response:      response                         response
        :param timg:      顶图                                 str
        :return:         这个网页所有新闻图片的url              list
        """
        a = [timg] + list(pic_url) if pic_url else [timg]
        b = []
        if a:
            for i in set(a):
                try:
                    print('图片列表是======》》', set(a))
                    print('开始下载图片。。。。。。。。。')
                    self.pic_download(response, response.urljoin(i))   # 下载图片
                    b.append('{}.{}'.format(self.hash(response.urljoin(i)), i.split('.')[-1]))
                    print('图片下载写入完成，加入列表。。。。。。。。')
                except Exception as e:
                    print('=====图片下载失败，原因：', e)
            return b

    def parse_video(self, response):
        video_list = response.xpath('.//div[@class="cardContent"]//a/@href').extract()
        if video_list:
            for vurl in video_list:
                yield Request(vurl, callback=self.parse_item)

    def rename_hook(self, d):
        if d['status'] == 'finished':
            print('Done Downloading!!!')

    def download_video(self, youtube_url):
        try:
            ydl_opts = {
                'format': 'bestvideo[ext=mp4]',
                'outtmpl': './videos/%s.mp4' % (self.hash(youtube_url)),
                'progress_hooks': [self.rename_hook],
                'writeautomaticsub': True,
                'subtitleslangs': 'en',
            }
            with youtube_dl.YoutubeDL(ydl_opts) as ydl:
                print('开始下载视频。。。。。。。。。')
                ydl.download([youtube_url])
                print('视频下载完成。。。。。。。。。')
                return ydl_opts.get('outtmpl')
        except Exception as e:
            print('=====视频下载失败，原因：', e)
            return ''

    def news_content(self, response):     # 中文网站内容
        contents = response.xpath('.//div[@class="entry-content clearfix"]//p[position()]//text()').extract()
        if contents:
            return ''.join(contents)

    def news_image(self, response):
        imgs = response.xpath('.//a[@class="prettyphoto"]/img/@src').extract()
        if imgs:
            return imgs

    def news_time(self, response):
        times = response.xpath('.//p[@class="default_date"]/span/text()').extract()
        if times:
            ti = '-'.join(times)
            return ti

    def news_title(self, response):
        titles = response.xpath('.//h1[@class="post-title entry-title"]/text()').extract()
        return titles[0].strip().strip('\n') if titles else ''

    def parse_item(self, response):
        try:
            a = Article(response.url)
            a.set_html(response.text)
            a.parse()

            item = XzItem()

            item['url'] = response.url
            item['category'] = 'Latest news'
            item['title'] = self.news_title(response) or a.title
            item['time'] = self.news_time(response)
            item['content'] = self.news_content(response) or a.text             # 中文网站要重写一下
            item['img_path'] = ['./images/{}'.format(img) for img in
                                self.article_img(self.news_image(response), a.top_image, response)]
            item['video_path'] = self.download_video(response.url)
            yield item
        except Exception as e:
            print('======>>>发生错误:', e)
            print('======>>>下载失败，url:', response.url)
