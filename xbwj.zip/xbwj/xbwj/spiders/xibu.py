# -*- coding: utf-8 -*-
import scrapy
import hashlib
import os
import stat
import requests
import youtube_dl
import dateparser
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
from scrapy.utils.project import get_project_settings
from xbwj.items import XbwjItem
from newspaper import Article


class XibuSpider(CrawlSpider):
    name = 'xibu'
    allowed_domains = ['tibet.net']
    start_urls = ['https://www.tibet.net/']

    rules = (
        Rule(LinkExtractor(allow=r'/2019/.*'), follow=False, callback='is_download'),
        Rule(LinkExtractor(allow=r'https://tibet.net/category/flash-news/$'), follow=True, callback='ajax_page'),
        Rule(LinkExtractor(allow=r'https://tibet.net/posts/announcements/$'), follow=True),
        Rule(LinkExtractor(allow=r'https://tibet.net/statements/tibetan-parliament-in-exile/$'), follow=True),
        Rule(LinkExtractor(allow=r'https://tibet.net/category/news-from-other-sites/$'), follow=True),
        Rule(LinkExtractor(allow=r'https://tibet.net/situation-in-tibet-updates/$'), follow=True),
        Rule(LinkExtractor(allow=r'https://tibet.net/posts/periodicals/$'), follow=True),
        Rule(LinkExtractor(allow=r'https://tibet.net/posts/publications/$'), follow=True),
        Rule(LinkExtractor(allow=r'https://tibet.net/archive/$'), follow=True),
        Rule(LinkExtractor(allow=r'https://tibet.net/about-tibet/.*'), follow=False, callback='parse_item'),
        Rule(LinkExtractor(allow=r'https://tibet.net/about-cta/.*'), follow=False, callback='is_download'),
        Rule(LinkExtractor(allow=r'https://tibet.net/department/.*'), follow=False, callback='is_download'),
    )

    def ajax_page(self, response):
        for i in range(1, 16):
            url = 'https://tibet.net/category/flash-news/?fwp_paged={}'.format(i)
            yield scrapy.Request(url, callback=self.ah)

    def ah(self, response):
        links = response.xpath('.//a[contains(@href, 2019)]/@href').extract()
        if links:
            for link in links:
                yield scrapy.Request(response.urljoin(link), callback=self.parse_item)

    def is_download(self, response):
        if 'DOWNLOAD' in response.text:

            download_url = response.xpath('.//a[contains(text(), "DOWNLOAD")]/@href').extract()
            al = []
            for d in download_url:
                try:
                    yield scrapy.Request(response.urljoin(d), meta=response.meta, callback=self.parse_item)
                    print('开始下载pdf。。。。。。。。。')
                    self.pdf_download(response.urljoin(d), response)
                    print('pdf下载写入完成。。。。。。。。。')
                    al.append('./news_pdf/{}.pdf'.format(self.hash(response.urljoin(d))))

                except Exception as e:
                    print('=====pdf下载失败，原因：', e)
                    continue
            response.meta['pdf'] = al

        else:
            yield scrapy.Request(response.url, callback=self.parse_item)

    def pdf_download(self, download_url, response):    # 下载pdf

        paths = './news_pdf'
        if not os.path.exists(paths):
            os.makedirs(paths)

        os.chmod("./news_pdf", stat.S_IWOTH)
        pat = paths + '/{}.pdf'.format(self.hash(download_url))
        header = get_project_settings().get('DEFAULT_REQUEST_HEADERS')
        with open(pat, 'wb') as f:
            f.write(requests.get(download_url, headers=header).content)

    def pic_download(self, response, purl):    # 下载图片,purl:被下载图片的url
        """

        :param purl:   每个图片的url
        :param response:   response
        :return:       图片列表
        """
        paths = './image'
        if not os.path.exists(paths):
            os.makedirs(paths)
            os.chmod("./image", stat.S_IWOTH)  # 可被写入
        pat = paths + '/{}.{}'.format(self.hash(purl), purl.split('.')[-1])  # 可能有png格式 0330
        header = get_project_settings().get('DEFAULT_REQUEST_HEADERS')
        picture = requests.get(purl, headers=header).content  # 先下载资源再创建文件，避免文件创建出来却没下载成功，空文件情况
        with open(pat, 'wb') as f:
            f.write(picture)

    def article_img(self, pic_url, timg, response):
        """

        :param pic_url:  这个网页的所有图片url（包括非新闻的）   set
        :param response:      response                         response
        :param timg:      顶图                                 str
        :return:         这个网页所有新闻图片的url              list
        """
        a = [timg] + list(pic_url) if pic_url else [timg]
        b = []
        if a:
            for i in set(a):
                try:
                    print('图片列表是======》》', set(a))
                    print('开始下载图片。。。。。。。。。')
                    self.pic_download(response, response.urljoin(i))   # 下载图片
                    b.append('{}.{}'.format(self.hash(response.urljoin(i)), i.split('.')[-1]))
                    print('图片下载写入完成，加入列表。。。。。。。。')
                except Exception as e:
                    print('=====图片下载失败，原因：', e)
            return b

    def hash(self, url):
        m = hashlib.md5()
        m.update(url.encode("utf8"))
        return m.hexdigest()

    def rename_hook(self, d):
        if d['status'] == 'finished':
            print('Done Downloading!!!')

    def download_video(self, youtube_url):
        try:
            ydl_opts = {
                'format': 'bestvideo[ext=mp4]',
                'outtmpl': './videos/%s.mp4' % (self.hash(youtube_url)),
                'progress_hooks': [self.rename_hook],
                'writeautomaticsub': True,
                'subtitleslangs': 'en',
            }
            with youtube_dl.YoutubeDL(ydl_opts) as ydl:
                print('开始下载视频。。。。。。。。。')
                ydl.download([youtube_url])
                print('视频下载完成。。。。。。。。。')
                return ydl_opts.get('outtmpl')
        except Exception as e:
            print('=====视频下载失败，原因：', e)
            return ''

    def news_content(self, response):     # 中文网站内容
        contents = response.xpath('.//div[@class="entry-content"]//p[position()]//text()').extract()
        if contents:
            return ''.join(contents)

    def news_image(self, response):
        imgs = response.xpath('.//div[@class="entry-content"]//img/@src').extract()
        if imgs:
            return imgs

    def news_time(self, response):
        times = response.xpath('.//dl[@class="article-info muted"]//dd[@title="Published: "]/time/text()').extract()
        # if times:
        #     ti = '-'.join(times)
        return times[0].strip().strip('\n') if times else ''

    def news_title(self, response):
        titles = response.xpath('.//h2[@class="page-title"]/text()').extract()
        return titles[0].strip().strip('\n') if titles else ''

    def parse_item(self, response):

        if not response.url.endswith('.pdf'):
            # try:
            a = Article(response.url)
            a.set_html(response.text)
            a.parse()

            time = response.xpath('.//div[@class="single_meta_item single_meta_date"]/text()').extract()

            item = XbwjItem()

            item['url'] = response.url
            item['title'] = a.title
            item['time'] = time[0] if time else response.meta.get('time', '')
            item['content'] = a.text
            # item['image'] = self.article_img(self.news_image(response), a.top_image, response)
            # item['img_path'] = './image/{}'.format(self.hash(response.url))
            item['img_path'] = ['./images/{}'.format(img) for img in self.article_img(self.news_image(response), a.top_image, response)]
            # item['video_path'] = './videos/%s' % (self.download_video(response.url))
            item['video_path'] = self.download_video(response.url)
            item['pdf_path'] = response.meta.get('pdf', '')
            yield item
            print('=============item yield成功===========')
        # except Exception as e:
        #     print('======>>>发生错误:', e)
        #     print('======>>>下载失败，url:', response.url)
        # finally:
        #     self.download_video(response.url)  # 下视频
