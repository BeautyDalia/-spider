# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html

from . import settings
from scrapy.exceptions import DropItem
from scrapy import Request


# class XbwjPipeline(object):
#     def process_item(self, item, spider):
#         return item

